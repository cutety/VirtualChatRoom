package frame;

import bean.Message;
import bean.MessageType;

import frame.FrameTools.ButtonInit;
import frame.FrameTools.FrameAlignCenter;
import frame.FrameTools.FrameMoveByMouse;
import javafx.util.Builder;
import tools.ManageClientConServerThread;

import javax.sound.sampled.Line;
import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatFrame extends JFrame implements ActionListener, FocusListener,KeyListener,MouseListener{
    /*
    聊天界面共有5个部分
    一、聊天对象ID
    二、聊天内容
    三、聊天工具
    四、输入框
    五、发送
     */
    private String filePath="src/chatHistory.txt";
    private JPanel chatInterface,taskBar;
    private JLabel avatar,name;
    private JTextPane chatInterfaceText;
    private JPanel toolsBar;
    private JPanel bottonBar;
    private JScrollPane chatSlp;
    private JPanel senderBar;
    private JScrollPane senderBarSlp;
    private JTextArea senderBarTf;
    private JButton send;
    private JButton exit;
    private JButton minimize,exitBtn;
    private String firend=null;
    private String owenerId=null;
    private Document doc;
    private JScrollBar jScrollBar;
    private Point  screenCord, newCord;
    private Point origin;
    String info,textInfo;

    public static void main(String[] args) {
        new ChatFrame("汤圆","null");
    }
    public ChatFrame(String owenerId,String friend){
        this.owenerId=owenerId;
        this.firend=friend;
        try {
            init();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public void init(){
        //第一部分
        System.out.println("第一部分初始化成功");
        this.setUndecorated(true);
        this.setTitle("与"+firend+"的对话");
        int windowWidth=615;
        int windowHeight=605;
        this.setSize(windowWidth,windowHeight);
        this.setLayout(null);
        this.setBackground(new Color(30, 144, 255));
        //设置窗口居中
       /* int width=Toolkit.getDefaultToolkit().getScreenSize().width;
        int height=Toolkit.getDefaultToolkit().getScreenSize().height;
        this.setBounds((width-windowWidth)/2,(height-windowHeight)/2,windowWidth,windowHeight);*/
        new FrameAlignCenter(this);
        this.setDefaultCloseOperation(getDefaultCloseOperation());
        taskBar(firend);
        //第一部分
        setChatInterface();
        System.out.println("第二部分初始化成功");
        //第二部分
        setToolsBar();
        //第三部分
        setSenderBar();
        //第四部分
        setBottonBar();

        this.setVisible(true);
    }
    public void taskBar(String friend){

        taskBar=new JPanel();
        name=new JLabel(friend);
        name.setBounds(90,10,60,30);
        taskBar.add(name);
        avatar=new JLabel(new ImageIcon("src/frame/image/tempheadportrait.jpg"));
        avatar.setBounds(5,5,60,60);
        taskBar.add(avatar);
        taskBar.setLayout(null);
        taskBar.setBackground(new Color(30, 144, 255));
        taskBar.setBounds(0,0,615,70);
        minimize=new JButton();
        new ButtonInit(minimize,"src/frame/image/sysbtn_min_normal.png","src/frame/image/sysbtn_min_hover.png","src/frame/image/sysbtn_min_down.png");
        minimize.setBounds(555,0,30,27);
        minimize.addActionListener(this);
        taskBar.add(minimize);
        exitBtn=new JButton();
        new ButtonInit(exitBtn,"src/frame/image/sysbtn_close_normal.png","src/frame/image/sysbtn_close_hover.png","src/frame/image/sysbtn_close_down.png");
        exitBtn.setBounds(585,0,30,27);
        exitBtn.addActionListener(this);
        taskBar.add(exitBtn);
        taskBar.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                origin = new Point(0, 0);
                origin.x = e.getX();
                origin.y = e.getY();
            }
        });
        taskBar.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                screenCord = new Point(e.getXOnScreen(), e.getYOnScreen());
                newCord = new Point(screenCord.x - origin.x, screenCord.y - origin.y);
                ChatFrame.this.setLocation(newCord);
            }
        });

        this.add(taskBar);
    }
    public void setChatInterface(){
        chatInterface=new JPanel();
        chatInterface.setLayout(null);
        chatInterface.setBounds(0,70,615,320);
        chatSlp=new JScrollPane();
        chatSlp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        chatInterfaceText=new JTextPane();
        //chatInterfaceText.setText(readString());
        chatInterfaceText.setBounds(0,0,615,320);
        chatInterfaceText.setOpaque(false);
        chatInterfaceText.setEditable(false);
        chatSlp.setBounds(0,0,615,320);
        chatSlp.getViewport().setBackground(Color.white);
        chatSlp.setViewportView(chatInterfaceText);

        chatInterface.add(chatSlp);
        this.add(chatInterface);
    }
    public void setToolsBar(){
        toolsBar=new JPanel();
        toolsBar.setBackground(Color.white);
        toolsBar.setBounds(1,390,599,20);
        this.add(toolsBar);


    }
    public void setSenderBar(){
       senderBarSlp=new JScrollPane();
       /*senderBarSlp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);*/

       senderBar=new JPanel();
       senderBar.setLayout(null);
       senderBar.setBounds(0,410,615,160);
       senderBarTf=new JTextArea();
       senderBarTf.setBounds(0,0,615,160);
       senderBarTf.setOpaque(false);
       senderBarTf.setForeground(Color.red);
       senderBarTf.addFocusListener(this);
       senderBarTf.addKeyListener(this);

       senderBarSlp.setBounds(0,0,615,160);
       senderBarSlp.getViewport().setBackground(Color.white);
       senderBarSlp.setViewportView(senderBarTf);
       senderBar.add(senderBarSlp);
       this.add(senderBar);


    }
    public void setBottonBar(){
        bottonBar=new JPanel();
        bottonBar.setBounds(0,570,615,35);
        bottonBar.setBackground(new Color(30, 144, 255));
        bottonBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
        exit=new JButton("退出");
        bottonBar.add(exit);
        exit.addActionListener(this);
        send=new JButton("发送");
        send.addActionListener(this);
        bottonBar.add(send);
        this.add(bottonBar);
    }
    public void showMessage(Message m){
        Date now=new Date();
        SimpleDateFormat ft=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        info=m.getSender()+"  "+ft.format(now);
        SimpleAttributeSet sab=new SimpleAttributeSet();
        StyleConstants.setForeground(sab,new Color(0,0,255));
        stringInsertTitle(info,sab);
        textInfo=m.getContent();
        stringInsertContent(textInfo,null);
        updateScroll();
    }
    //显示聊天记录，目前如果聊天记录太多的话会很慢很慢才能打开对话框
    public String readString(){
        String str="";

        File file=new File("src/chatHistory.txt");

        try {

            FileInputStream in=new FileInputStream(file);

            // size  为字串的长度 ，这里一次性读完

            int size=in.available();

            byte[] buffer=new byte[size];

            in.read(buffer);

            in.close();

            str=new String(buffer,"utf-8");

        } catch (IOException e) {
            e.printStackTrace();
            // TODO Auto-generated catch block

            return null;



        }

        return str;
    }
    public void updateScroll(){
        chatInterfaceText.setCaretPosition(chatInterfaceText.getStyledDocument().getLength());
    }
    public void sendAction(){
        //在控制台回显发送的内容便于调试
        System.out.println("发送的内容"+senderBarTf.getText());
        Message m=new Message();
        m.setMessageType(MessageType.message_comm_mes);
        m.setSender(owenerId);
        m.setReciever(firend);
        m.setContent(senderBarTf.getText());
        Date now=new Date();
        SimpleDateFormat ft=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        info=m.getSender()+"  "+ft.format(now)+"\n";
        m.setTime(info);
        textInfo=senderBarTf.getText()+"\n";
        SimpleAttributeSet attributeSet=new SimpleAttributeSet();
        StyleConstants.setForeground(attributeSet,new Color(	67, 205, 128));
        stringInsertTitle(info,attributeSet);
        StyleConstants.setForeground(attributeSet, Color.black);
        chatInterfaceText.setForeground(Color.black);
        stringInsertContent(textInfo,attributeSet);
        senderBarTf.setText("");
        //将聊天记录保存到本地
        try {
            FileWriter fw=new FileWriter(filePath,true);
            BufferedWriter bw=new BufferedWriter(fw);
            bw.append(chatInterfaceText.getText());
            bw.close();
            fw.close();
        }catch (Exception e){
            e.printStackTrace();
        }

        //将信息发送给服务器
        try {
            ObjectOutputStream oos=new ObjectOutputStream
                    (ManageClientConServerThread.getClientConServerThread(owenerId).getS().getOutputStream());
            oos.writeObject(m);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==exit){

            this.dispose();
        }else if(e.getSource()==send){
            sendAction();
            updateScroll();

        }
    }

    public void stringInsertTitle(String s, SimpleAttributeSet attrset){
        doc=chatInterfaceText.getDocument();
        s="\n"+s;
        try{
            doc.insertString(doc.getLength(),s,attrset);
        }catch (Exception e1){
            e1.printStackTrace();
        }
    }
    public void stringInsertContent(String s, SimpleAttributeSet attrset){
        doc=chatInterfaceText.getDocument();
        s="\n"+s;
        try{
            doc.insertString(doc.getLength(),s,attrset);
        }catch (Exception e1){
            e1.printStackTrace();
        }
    }

    @Override
    public void focusGained(FocusEvent e) {

    }

    @Override
    public void focusLost(FocusEvent e) {

    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource()==senderBarTf){
            if(e.getKeyCode()==KeyEvent.VK_ENTER){
                sendAction();
                updateScroll();
            }else if(e.isAltDown()&&e.getKeyCode()==KeyEvent.VK_C){
                this.dispose();
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
