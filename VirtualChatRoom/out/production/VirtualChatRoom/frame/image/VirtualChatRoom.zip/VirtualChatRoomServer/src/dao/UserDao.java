package dao;

import bean.Message;
import bean.User;
import model.CheckTableExists;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
    public static boolean userRegist(User user) {
        Connection conn = null;
        try {
            String userid = user.getUserId();
            String password = user.getUserPwd();
            conn = DAO.getConn();
            PreparedStatement ps = conn.prepareStatement("insert into user (user_id,user_password) values (?,?)");
            ps.setString(1, userid);
            ps.setString(2, password);
            PreparedStatement ps1=conn.prepareStatement("select count(*) from user where user_id=?");
            ps1.setString(1,userid);
            ResultSet rs=ps1.executeQuery();
            if(rs.next()&&rs.getRow()>0){
                int flag = ps.executeUpdate();
                if(flag>0){
                    System.out.println("注册成功");
                    //顺便给该账号添加一个好友列表
                    Message mu=new Message();
                    mu.setSender(userid);
                    new CheckTableExists(mu,conn);
                    System.out.println("好友列表数据库初始化完毕");
                    return true;
                }else{
                    System.out.println("注册失败");
                    return false;
                }
            }else{
                System.out.println("用户名已存在");
                return false;
            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    public static boolean userLogin(User user) {
        Connection conn = null;
        try {
            System.out.println("正在验证账号密码合法性");
            String userid = user.getUserId();
            String password = user.getUserPwd();
            System.out.println("1");
            conn = DAO.getConn();
            System.out.println("2");
            PreparedStatement ps = conn.prepareStatement("select user_password from user where user_id=?");
            ps.setNString(1, userid);
            ResultSet rs = ps.executeQuery();
            System.out.println("查询账号密码成功");
            if (rs.next() && rs.getRow() > 0) {
                String pwd = rs.getString(1);
                System.out.println("正确的密码是" + pwd);
                System.out.println("输入的密码是" + password);
                if (pwd.equals(password)) {
                    System.out.println("账号密码正确");
                    return true;
                } else {
                    System.out.println("密码错误");

                    return false;
                }

            } else {
                System.out.println("用户不存在");

                return false;
            }
        } catch (Exception e) {
            System.out.println("数据库异常");
            JOptionPane.showMessageDialog(null, "数据库异常");
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
