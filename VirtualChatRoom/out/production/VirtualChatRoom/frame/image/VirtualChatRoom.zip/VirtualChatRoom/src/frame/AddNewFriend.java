package frame;

import bean.Message;
import bean.MessageType;
import frame.FrameTools.FrameAlignCenter;
import tools.ManageClientConServerThread;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;

public class AddNewFriend extends JFrame implements ActionListener {

    private JLabel friendId;
    private JTextField tfFirendId;
    private JButton add,cancel;
    private ObjectOutputStream oos;
    private String owenerId;
    public static void main(String[] args) {
        new AddNewFriend("null");
    }
    public AddNewFriend(String owenerId){
        this.owenerId=owenerId;
        init();
    }
    public void init(){
        this.setTitle("添加好友");
        this.setSize(300, 120);
        this.setAlwaysOnTop(true);
        this.setLayout(new GridLayout(2,2));
        new FrameAlignCenter(this);
        friendId=new JLabel("用户名");
        tfFirendId=new JTextField(10);
        add=new JButton("添加");
        add.setBounds(new Rectangle(30,30));
        add.addActionListener(this);
        cancel=new JButton("取消");
        cancel.setBounds(new Rectangle(30,30));
        cancel.addActionListener(this);
        this.add(friendId);
        this.add(tfFirendId);
        this.add(add);
        this.add(cancel);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==cancel){
            this.dispose();
        }else if(e.getSource()==add){
            String friendId=tfFirendId.getText().trim();
            try {
                oos = new ObjectOutputStream(ManageClientConServerThread.getClientConServerThread(owenerId).getS().getOutputStream());
                Message m = new Message();
                m.setContent(friendId);
                m.setMessageType(MessageType.message_request_addFriend);
                m.setSender(owenerId);
                oos.writeObject(m);
                System.out.println(owenerId+"成功添加"+friendId+"为好友~");
            }catch ( Exception e1){
                e1.printStackTrace();
            }
        }
    }
}
