package bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Message implements Serializable {

    private static final long serialVersionUID = 8141984962750547675L;
    private String messageType;
    private String sender;
    private String reciever;
    private String content;
    private String time;
    private ArrayList<String> friendList;
    private int friendNum;

    public void setFriendNum(int friendNum) {
        this.friendNum = friendNum;
    }

    public int getFriendNum() {
        return friendNum;
    }

    public void setFriendList(ArrayList<String> friendList) {
        this.friendList = friendList;
    }

    public ArrayList<String> getFriendList() {
        return friendList;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setReciever(String reciever) {
        this.reciever = reciever;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSender() {
        return sender;
    }

    public String getReciever() {
        return reciever;
    }

    public String getContent() {
        return content;
    }

    public String getTime() {
        return time;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }
}
