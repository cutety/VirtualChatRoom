package tools;

import frame.MainFrame;

import java.util.HashMap;

public class ManageFirendList {
    private static HashMap hm=new HashMap<String, MainFrame>();
    //添加主界面
    public static void addMainFrame(String id,MainFrame mainFrame){
        hm.put(id,mainFrame);

    }
    //返回主界面
    public static MainFrame getMainFrame(String id){
        return (MainFrame)hm.get(id);
    }
}
