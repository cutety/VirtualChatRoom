/*
服务器和某个客户端的通信线程
 */
package model;

import Functions.FileTransfer;
import bean.Message;
import bean.MessageType;
import dao.DAO;
import dao.SelectQuery;
import jdk.nashorn.internal.ir.Flags;

import javax.sound.midi.Soundbank;
import javax.swing.plaf.SeparatorUI;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.math.RoundingMode;
import java.net.Socket;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ServerConClientThread extends Thread {
    Socket s;
    private String offLineUser;

    private Message m;

    public ServerConClientThread(Socket s) {
        //把服务器与该客户端的连接赋给s
        this.s = s;
    }

    //让该线程通知其他用户
    public void notifyOtherOnlieUsers(String whoAmI) {
        //得到所有的线程
        HashMap hm = ManageClientThread.hm;
        Iterator it = hm.keySet().iterator();
        while (it.hasNext()) {
            Message m = new Message();
            m.setContent(whoAmI);
            m.setMessageType(MessageType.message_newOnline_friend);
            m.setFriendNum(Integer.MAX_VALUE);
            m.setFriendList(null);
            //取出在线用户id
            String onLineUserId = it.next().toString();
            System.out.println("新上线人:" + whoAmI);

            try {
                ObjectOutputStream oos = new ObjectOutputStream(ManageClientThread.getClientThread(onLineUserId).s.getOutputStream());
                m.setReciever(onLineUserId);
                System.out.println("接收人:"+onLineUserId);
                oos.writeObject(m);
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }

    public void notifyOtherOnlieUsersOff(String whoAmI) {
        //得到所有的线程
        HashMap hm = ManageClientThread.hm;
        Iterator it = hm.keySet().iterator();
        while (it.hasNext()) {

            //取出在线用户id
            String onLineUserId = it.next().toString();
            System.out.println("当前在线用户为:" + onLineUserId);
            try {
                ObjectOutputStream oos = new ObjectOutputStream(ManageClientThread.getClientThread(onLineUserId).s.getOutputStream());
                Message m3 = new Message();
                m3.setContent(onLineUserId);
                m3.setSender(whoAmI);
                m3.setMessageType(MessageType.message_ret_logout);
                m3.setReciever(onLineUserId);
                oos.writeObject(m3);
                System.out.println("通知"+ whoAmI + "下线");
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void run() {
        while (true) {
            //该线程可以接受客户端的信息
            try {

                //读取客户端发送的消息
                if (s.getInputStream().available() != 0) {//使用inputStream.available判断是否还有字节流可读，如果没有就不执行下面的语句。

                    ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
                    m = (Message) ois.readObject();
                    System.out.println(m.getSender() + "给服务器发送了一条消息");
                    //对客户端的消息进行类型分类判断进行处理
                    if (m.getMessageType().equals(MessageType.message_comm_mes)) {
                        //转发
                        //取得接收人的通信线程
                        System.out.println(m.getSender() + "在聊天");
                        ServerConClientThread sc = ManageClientThread.getClientThread(m.getReciever());
                        ObjectOutputStream oos = new ObjectOutputStream(sc.s.getOutputStream());
                        oos.writeObject(m);
                    } else if (m.getMessageType().equals(MessageType.message_get_onLineFriend)) {

                        System.out.println(m.getSender() + "请求查看好友在线情况");
                        //返回给客户端，目前在线的好友
                        String res = ManageClientThread.getAllOnlineUserId();
                        System.out.println("目前在线人为：" + res);
                        Message m2 = new Message();
                        m2.setMessageType(MessageType.message_ret_onLineFriend);
                        m2.setContent(res);
                        m2.setReciever(m.getSender());
                        Connection conn = null;
                        conn = DAO.getConn();
                        //返回给客户端，客户端的昵称
                        String sql1="select user_name from user where user_id="+m.getSender();
                        SelectQuery selectQuery=new SelectQuery();
                        System.out.println("请求发送人:"+selectQuery.querySql(sql1));
                        m2.setName(selectQuery.querySql(sql1));
                        //返回给客户端好友的昵称

                        //返回给客户端目前好友列表中的好友id

                        PreparedStatement ps = null;
                        ResultSet rs = null;
                        String sql = "select * from " + m.getSender() + "_friend";
                        ArrayList<String> friendlist = new ArrayList<>();
                        ArrayList<String> friendNameList=new ArrayList<>();
                        try {
                            ps = conn.prepareStatement(sql);
                            rs = ps.executeQuery();
                            int count = 0;
                            while (rs.next()) {

                                friendlist.add(rs.getString("name"));//获取好友ID
                                friendNameList.add(rs.getString("user_name"));
                                count++;//记录好友个数
                            }
                            System.out.println("ID: ");
                            for(String temp:friendlist){
                                System.out.print(temp+"\t");
                            }

                            System.out.println("\n昵称:");
                            for(String temp:friendNameList){
                                System.out.print(temp+" ");
                            }
                            System.out.println("好友个数:"+count);
                            m2.setFriendList(friendlist);//好友id列表
                            m2.setFriendNameList(friendNameList);//好友昵称列表
                            m2.setFriendNum(count);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(m2);
                    } else if (m.getMessageType().equals(MessageType.message_request_addFriend)) {
                        System.out.println(m.getSender() + "请求加" + m.getContent() + "好友");
                        //将这他想加的好友加到双方的好友列表中
                        //检查数据库中是否有该账号
                        //首先检索数据库中该账号和好友账号是否建立了好友table,有则直接使用，无则创建

                        Connection conn = null;
                        conn = DAO.getConn();
                       /* String creatTb = "create table " + m.getSender() + "_friend "
                                + "(id int(10) NOT NULL, "
                                + "name varchar(255), "
                                + "PRIMARY KEY (id))";
                        String tn=m.getSender()+"_friend";
                        String checkTb = "show tables like \"tn\"";
                        try {
                            Statement st = (Statement) conn.createStatement();
                            ResultSet rs = st.executeQuery(checkTb);
                            if (rs.next()) {
                                flag = 1;
                            } else {
                                if (st.executeUpdate(creatTb) == 0) {
                                    flag = 1;
                                }
                            }
                        } catch (Exception ew) {
                            ew.printStackTrace();
                        }*/
                        Message m2 = new Message();
                        PreparedStatement ps = null;
                        PreparedStatement ps2 = null;
                        PreparedStatement ps3=null;
                        PreparedStatement ps4=null;
                        String sql = "insert into " + m.getSender() + "_friend (name) values(?)";
                        String sql2 = "insert into " + m.getContent() + "_friend (name) values (?)";
                        String sql3 = "insert into " + m.getSender() + "_friend (user_name) values (?)";
                        String sql4 = "insert into " + m.getContent() + "_friend (user_name) values (?)";
                        try {
                            ps = conn.prepareStatement(sql);
                            ps2 = conn.prepareStatement(sql2);
                            ps2 = conn.prepareStatement(sql3);
                            ps2 = conn.prepareStatement(sql4);
                            ps.setString(1, m.getContent());
                            ps.executeUpdate();
                            ps2.setString(1, m.getSender());
                            ps2.executeUpdate();
                            ps2.setString(1, m.getContent());
                            ps3.executeUpdate();
                            ps4.setString(1, m.getSender());
                            ps4.executeUpdate();
                            m2.setMessageType(MessageType.message_addFriend_permit);
                        } catch (Exception ep) {
                            ep.printStackTrace();
                        } finally {
                            try {
                                if (ps != null) {
                                    ps.close();
                                }
                                if (ps2 != null) {
                                    ps2.close();
                                }
                            } catch (Exception e1) {
                                e1.printStackTrace();
                            }
                        }
                        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(m2);
                    } else if (m.getMessageType().equals(MessageType.message_request_logout)) {
                        System.out.println(m.getSender()+ "请求下线");
                        ManageClientThread.hm.remove(m.getSender());
                        System.out.println("删除"+m.getSender()+ "的hashMap值,剩余在线人" + ManageClientThread.getAllOnlineUserId());
                        System.out.println(m.getSender() + "已下线");
                        notifyOtherOnlieUsersOff(m.getSender());

                        System.out.println("关闭服务器与" + m.getSender()+"的连接");
                    } else if (m.getMessageType().equals(MessageType.message_get_logout)) {
                        System.out.println(m.getSender() + "请求查看目前好友状况");
                        String res = ManageClientThread.getAllOnlineUserId();
                        System.out.println("目前在线人为：" + res);
                        Message m2 = new Message();
                        m2.setMessageType(MessageType.message_ret_logout);
                        m2.setContent(res);
                        m2.setReciever(m.getSender());
                        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                        oos.writeObject(m2);

                    }


                }
            } catch (Exception e) {
                //ManageClientThread.hm.remove(m.getSender());
                //System.out.println("删除了key为" + m.getSender() + "的hashMap值,剩余在线人" + ManageClientThread.getAllOnlineUserId());
                e.printStackTrace();
                break;


            }

        }
    }

}
