package frame;

import bean.Message;
import bean.MessageType;
import com.sun.javafx.scene.traversal.TopMostTraversalEngine;
import dao.UserDao;
import bean.User;
import frame.FrameTools.DialogFrame;
import frame.FrameTools.FrameAlignCenter;
import javafx.stage.Modality;
import model.ClientUser;
import tools.ManageClientConServerThread;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;

public class RegistFrame extends JFrame implements ActionListener {
    public static void main(String[] args) {
        new RegistFrame();
    }

    public RegistFrame() {
        init();
    }

    private JLabel id, password, conPswd;
    private JTextField tfId, tfPsw, tfConPsw;
    private JButton regist, cancel;
    private ObjectOutputStream oos;

    public void init() {
        this.setTitle("Regist yur account");
        this.setSize(300, 200);
        this.setLayout(new GridLayout(4, 2));
        this.setAlwaysOnTop(true);
        new FrameAlignCenter(this);
        id = new JLabel("id");
        password = new JLabel("password");
        conPswd = new JLabel("confirm password");
        tfId = new JTextField(10);
        tfPsw = new JTextField(10);
        tfConPsw = new JTextField(10);
        regist = new JButton("regist");
        cancel = new JButton("cancel");
        this.add(id);
        this.add(tfId);
        this.add(password);
        this.add(tfPsw);
        this.add(conPswd);
        this.add(tfConPsw);
        this.add(regist);
        this.add(cancel);
        regist.addActionListener(this);
        cancel.addActionListener(this);
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == regist) {
            if (!tfPsw.getText().trim().equals(tfConPsw.getText().trim())) {
                System.out.println("重复密码不匹配");
                new DialogFrame("warning", "conpwd is not matched with password!", 300, 100);
            } else {
                User user = new User();
                user.setUserId(tfId.getText().trim());
                user.setUserPwd(tfPsw.getText().trim());
                ClientUser clientUser = new ClientUser();
                if (clientUser.checkRegist(user)) {
                    System.out.println("注册成功");
                    new DialogFrame("notify", "congrats,regist successfully!", 300, 100);
                } else {
                    System.out.println("注册失败");
                    new DialogFrame("warning", "regist failed,userId has been used or invalid id", 300, 100);
                }
            }
        } else if (e.getSource() == cancel) {
            this.dispose();
        }
    }
}
