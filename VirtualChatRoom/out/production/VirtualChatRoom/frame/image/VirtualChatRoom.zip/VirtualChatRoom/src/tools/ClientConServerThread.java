/*
客户端和服务器端保持通信的线程
 */
package tools;

import bean.Message;
import bean.MessageType;
import frame.ChatFrame;
import frame.MainFrame;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ClientConServerThread extends Thread {
    private Socket s;
    public int friendNum;
    public ArrayList<String> friendList;
    public Socket getS() {
        return s;
    }

    public ClientConServerThread(Socket s) {
        this.s = s;
    }

    public  int getFriendNum() {
        return friendNum;
    }

    public  ArrayList<String> getFriendList() {
        return friendList;
    }


    public void run() {
        while (true) {
            //等待读取从服务器端发来的消息
            try {
                if (s.getInputStream().available() != 0) {
                    ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
                    Message m = (Message) ois.readObject();

                    if (m.getMessageType().equals(MessageType.message_comm_mes)) {
                        //普通信息包，返回聊天内容
                        System.out.println("读取到:" + m.getSender() + "发送" + m.getContent() + "给" + m.getReciever());
                        //把从服务器获得的消息，显示到目标客户端的聊天界面
                        ChatFrame chatFrame = ManageChat.getChat(m.getReciever() + " " + m.getSender());
                        //显示
                        chatFrame.showMessage(m);
                    } else if (m.getMessageType().equals(MessageType.message_ret_onLineFriend)) {
                        //返回好友列表信息包

                        String content = m.getContent();
                        String friend[] = content.split(" ");
                        String reciever = m.getReciever();
                        friendList=m.getFriendList();
                        friendNum=m.getFriendNum();
                        MainFrame mainFrame = ManageFirendList.getMainFrame(reciever);

                        if (mainFrame != null) {
                            mainFrame.updateFirendList(m);
                            mainFrame.notifyOnline(m);

                        }
                    } else if (m.getMessageType().equals(MessageType.message_ret_logout)) {
                        //返回下线好友信息包
                        MainFrame mainFrame = ManageFirendList.getMainFrame(m.getReciever());
                        if (mainFrame != null) {
                            mainFrame.updateFriendOffLine(m);
                            mainFrame.notifyOnline(m);
                        }
                    }else if(m.getMessageType().equals(MessageType.message_addFriend_permit)){
                        System.out.println("添加成功,请重启客户端");
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
    }


}
