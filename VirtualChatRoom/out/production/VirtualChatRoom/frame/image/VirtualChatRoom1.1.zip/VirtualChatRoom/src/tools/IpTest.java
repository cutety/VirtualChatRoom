package tools;

import frame.ChatFrame;

import java.net.InetAddress;
import java.net.Socket;

public class IpTest {
    public static void main(String[] args)throws Exception {

    }
}
