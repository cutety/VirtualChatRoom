package frame;

import javax.swing.*;

public class RetraceAccount extends JFrame {
    public RetraceAccount(){

    }
}
